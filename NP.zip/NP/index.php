<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh" content="0;url=/NP/NP/index.php">
    <title>Redirecting...</title>
</head>
<body>
</body>
</html>
