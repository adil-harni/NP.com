<?php

//fetch_cart.php

session_start();

$total_price=0;
$total_item=0;
$discount_amount=0;
$total=0;
$subtotal=0;
$output = '
<div class="table-responsive" id="order_table">
	<table class="table table-bordered table-striped">
	<tr>  
        <th style="background-color: #05131c; color:white;" colspan="5">New Table orders</th>  		
        </tr>
		<tr>  
            <th style="background-color: #05131c; color:white;" width="50%">Name</th>  
            <th style="background-color: #05131c; color:white;" width="10%">Qty</th>  
            <th style="background-color: #05131c; color:white;" width="20%">Price</th>
            <th style="background-color: #05131c; color:white;" width="10%"></th> 
            <th style="background-color: #05131c; color:white;" width="5%"></th> 			
        </tr>
';
if(!empty($_SESSION["shopping_cart"]))
{
	foreach($_SESSION["shopping_cart"] as $keys => $values)
	{   
	    if(!empty($values["product_discount"])){
	    $discount_amount=$values["product_discount"];
		}
		else
		{
		$discount_amount=0;
		}
		$total=$values["product_quantity"] * $values["product_price"];
		$subtotal=$total - ($total * ($discount_amount/100));
		$output .= '
		<tr>
			<td style="vertical-align:middle;">'.$values["product_name"].'</td>
			<td style="vertical-align:middle;" align="center">'.$values["product_quantity"].'</td>
			<td style="vertical-align:middle;" align="center">'.number_format($values["product_price"]).'</td>
			<td align="center" style="vertical-align:middle;"> 
			<button  name="padd" class="btn btn-danger btn-xs padd" id="'. $values["product_id"].'">&#10009;</button>
			<button style="margin-top:5px; font-size:14px;" name="porminus" class="btn btn-danger btn-xs porminus" id="'. $values["product_id"].'">&minus;</button>
			</td>
			<td align="center" style="vertical-align:middle;"><button name="delete" class="btn btn-danger btn-xs delete" id="'. $values["product_id"].'">&#10008;</button></td>
		</tr>
		';
		$total_price +=$subtotal;
		$total_item = $total_item + 1;
	}
	$output .= '
	<tr>  
        <td colspan="2" align="right"><b>Total</b></td>  
        <td align="center">'.number_format($total_price).' IQD</td>  
        <td></td> 
<td></td> 		
    </tr>
	';
}
else
{
	$output .= '
    <tr>
    	<td colspan="5" align="center">
    		Your Cart is Empty!
    	</td>
    </tr>
    ';
}
$output .= '</table></div>';
$data = array(
	'cart_details'		=>	$output,
	'total_price'		=>	number_format($total_price).' IQD' ,
	'total_item'		=>	$total_item
);	

echo json_encode($data);


?>