<?php
ob_start();
session_start();
include('../config.php');
include('../dbcon.php');
//fetch_cart.php to Db
date_default_timezone_set("Asia/Baghdad");
		$discount_amount=0;
		$systemuser=$_SESSION['accfullname'];
		if(!empty($_SESSION["shopping_cart"]))
		{
			
			$tableid=$_POST['projectprolocation'];
			$paymenttype='N/A';
			
			$requestlistid= "SELECT * FROM order_table order by order_id desc limit 1 ";
						$resultllistid= mysqli_query($conn,$requestlistid);
						if(mysqli_num_rows($resultllistid) > 0)
						{
							while($rowns= mysqli_fetch_array($resultllistid))
						{
							$ordrrqu_id=$rowns['order_id']+1;	
						}
						}
						else{	
					$ordrrqu_id=1;
				}
		$datee=date('Y-m-d');
		$entrydatetime=date('Y-m-d H:i');
		$sqlinfo= "INSERT INTO `order_table`(`order_id`, `client_id`, `order_date`,`system_user`,`entry_datetime`,`payment_type`) VALUES   
									   ('$ordrrqu_id','$tableid','$datee','$systemuser','$entrydatetime','$paymenttype')";
				$resultlinfo= mysqli_query($conn,$sqlinfo); 
				 if($resultlinfo)
			 {
			
			foreach($_SESSION["shopping_cart"] as $keys => $values)
			{   
				if(!empty($values["product_discount"])){
				$discount_amount=$values["product_discount"];
				}
				else
				{
				$discount_amount=0;
				}
				$productqty=$values["product_quantity"];
				$productid=$values["product_id"];
				$productprice=$values['product_price'];
				if($productqty >0){
				$query = "SELECT * FROM tbl_product where product_id='".$productid."' ";
				$statement = $connect->prepare($query);
				if($statement->execute())
				{
					$resultlist = $statement->fetchAll();
					
					foreach($resultlist as $rows)
					{
					$categoryid=$rows['category_id'];
					$productname=$rows['product_name'];
					
				 $sqlgolist= "INSERT INTO `order_list_table`(`order_id`, `order_category_id`, `order_product_id`, `order_product_name`,`order_product_qty`,`order_product_price`)
													 VALUES ('$ordrrqu_id','$categoryid','$productid','$productname',$productqty,'$productprice')";
				 $resultlistinsert= mysqli_query($conn,$sqlgolist);
				 if($resultlistinsert)
				 {
				
			    echo "<script>window.location.assign('chcekout.php')</script>";
				 }

				 }
				}
			}		
				}
		}
			
		}

		ob_end_flush();
		?>