<?php
//index.php
ob_start();
session_start();
include ('../dbcon.php');
include ('../functions.php');
if(isset($_SESSION['posseetango_id']))
{
?>
<!DOCTYPE html>
<html>
	<head>
		<title>POS</title>
		<link href="../assets/larsalogo.png" rel="icon" type="image/png">
		<script src="js/jquery.min.js"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<script src="js/bootstrap.min.js"></script>
		<style>
		.popover
		{
		    width: 100%;
		    max-width: 800px;
		}
		</style>
	</head>
	<body style="background-color: #05131c;">
		<div class="container" style="background-color:white; padding-right:20px; padding-left:20px; border-radius:5px;">
			
			<div style="margin-bottom:5px; background-color: #05131c; color:white;">
			<br />
			<h4 align="center">
			<a href="../catagorytlist.php"> 
			<button class="btn"  style="background-color:white; color:#05131c;" ><span class="glyphicon glyphicon-home"></span>  Go Back</button>
			</a>
			<br><br>
			</h4>


 
			
			<p align="left">
	                    <a href="cart.php?catlistid=all&catproid=all&barcodelist=<?php echo $_GET['barcodelist']; ?>"> <button class="btn btn-sm" style="background-color: #05131c; color:white; display:inline; margin:3px;">All</button></a>
						<?php                         
                        $projectlist= "SELECT * FROM categories where status='Active' and category_id!=34 order by category_name";
						$resultclist= mysqli_query($conn,$projectlist);
						if(mysqli_num_rows($resultclist) > 0)
						{
							while($rows= mysqli_fetch_array($resultclist))
						{
		                  										
					    ?>
						<a  href="cart.php?catlistid=<?php echo $rows["category_id"]; ?>&catproid=<?php echo $rows["category_id"]; ?>&barcodelist=<?php echo $_GET['barcodelist']; ?>"><button class="btn btn-sm" style="background-color: #05131c; color:white; display:inline; margin:3px;"><?php  echo $rows["category_name"]; ?></button></a>
						<?php  
						}
						}	
						?>
			
			</p>
			</div>
			<br />


			<?php      
			$table=0;
			$come=$_GET['barcodelist'];                
                        $projectlist2= "SELECT * FROM res_tables where table_id=$come";
						$resultclist2= mysqli_query($conn,$projectlist2);
						if(mysqli_num_rows($resultclist2) > 0)
						{
							while($rows2= mysqli_fetch_array($resultclist2))
						{

							$table=$rows2["table_num"];

						}}?>
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid" style="background-color: #05131c; color:white;">
					<div class="navbar-header">
					<h4 style="padding:5px;">Table No: <?php echo $table; ?> ( Total <span class="total_price">0.00 IQD</span> )</h4>
					</div>
				</div>
			</nav>
			
			
			
		<div class="row">
		<div class="col-xl-5 col-md-5">
				<span id="cart_details"></span>
				<div align="right">
				 <form action="checkoutlist.php"  method="POST" style="display:inline;">
				 <input type="hidden"  name="projectprolocation"  value="<?php echo $_GET['barcodelist']; ?>" >
				
					<button class="btn btn-success" id="check_out_cart">
					<span class="glyphicon glyphicon-shopping-cart"></span>
					Order
					</button>
				</form>
					<a href="#" class="btn btn-danger" id="clear_cart">
					<span class="glyphicon glyphicon-trash"></span> Clear Order
					</a>
				</div>
			</div>
			
			
			
            <div class="col-xl-7 col-md-7">
			<div id="display_item">


			</div>
			<br><br>
			</div>
			<br><br><br>
		</div>
		</div>
		<br><br><br><br>
	</body>
</html>

<script> 



 
$(document).ready(function(){

	load_product();

	load_cart_data();
    
	function load_product()
	{
		
		var categoryid='<?php echo $_GET['catlistid'];  ?>';
		var barcode=<?php echo $_GET['barcodelist'];  ?>;
		$.ajax({
			url:"fetch_item.php",
			data: {categoryid:categoryid , barcode:barcode},
			method:"POST",
			success:function(data)
			{
				$('#display_item').html(data);
			}
		});
	}

	function load_cart_data()
	{
		$.ajax({
			url:"fetch_cart.php",
			method:"POST",
			dataType:"json",
			success:function(data)
			{
				$('#cart_details').html(data.cart_details);
				$('.total_price').text(data.total_price);
				$('.badge').text(data.total_item);
				
			}
		});
	}





	$('#cart-popover').popover({
		html : true,
        container: 'body',
        content:function(){
        	return $('#popover_content_wrapper').html();
			
        }
	});

	$(document).on('click', '.add_to_cart', function(){
		var product_id = $(this).attr("id");
		var product_name = $('#name'+product_id+'').val();
		var product_price = $('#price'+product_id+'').val();
		var product_quantity = $('#quantity'+product_id).val();
		var product_discount = $('#discount'+product_id).val();
		var product_batchno = $('#batchno'+product_id).val();
		var action = "add";
		if(product_quantity > 0)
		{
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, product_name:product_name, product_price:product_price, product_quantity:product_quantity, product_discount:product_discount, product_batchno:product_batchno, action:action},
				success:function(data)
				{
					load_cart_data();
					
				}
			});
		}
		else
		{
			alert("lease Enter Number of Quantity");
		}
	});

$(document).on('click', '.padd', function(){
		var product_id = $(this).attr("id");
		var action = 'padd';
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					
				}
			})
		
	});
	
	
	$(document).on('click', '.porminus', function(){
		var product_id = $(this).attr("id");
		var action = 'porminus';
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					
				}
			})
		
	});

	$(document).on('click', '.delete', function(){
		var product_id = $(this).attr("id");
		var action = 'remove';
		if(confirm("Are you sure you want to remove this product?"))
		{
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					$('#cart-popover').popover('hide');
					
				}
			})
		}
		else
		{
			return false;
		}
	});

	$(document).on('click', '#clear_cart', function(){
		var action = 'empty';
		$.ajax({
			url:"action.php",
			method:"POST",
			data:{action:action},
			success:function()
			{
				load_cart_data();
				$('#cart-popover').popover('hide');
				alert("Your invoice has been clear");
			}
		});
	});
    
});

</script>

<?php 
}
else{	
echo "<script>window.location.assign('index.php')</script>";
ob_end_flush();
 }  
?>
