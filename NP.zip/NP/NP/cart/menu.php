<?php
//index.php
ob_start();
session_start();
include ('../dbcon.php');
include ('../functions.php');

?>
<!DOCTYPE html>
<html>
	<head>
		<title>POS</title>
		<link href="../assets/larsalogo.png" rel="icon" type="image/png">
		<script src="js/jquery.min.js"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<script src="js/bootstrap.min.js"></script>
		<style>
		.popover
		{
		    width: 100%;
		    max-width: 800px;
		}
		</style>
	</head>
	<body style="background-color: #05131c;">
		<div class="container" style="background-color:white; padding-right:20px; padding-left:20px; border-radius:5px;">
			
			<div style="margin-bottom:5px; background-color: #05131c; color:white;">
			<br />
						<h4 align="center">

	<a href="http://localhost/CAFFE/"> 
			<button class="btn"  style="background-color:white; color:#05131c;" ><span class="glyphicon glyphicon-home"></span>  Go Back</button>
			</a>
			<br><br>
			</h4>


 
			
			<p align="left">
	                    <a href="menu.php?catlistid=all&catproid=all&barcodelist=<?php echo $_GET['barcodelist']; ?>"> <button class="btn btn-sm" style="background-color: #05131c; color:white; display:inline; margin:3px;">All</button></a>
						<?php                         
                        $projectlist= "SELECT * FROM categories where status='Active' and category_id!=34 order by category_name";
						$resultclist= mysqli_query($conn,$projectlist);
						if(mysqli_num_rows($resultclist) > 0)
						{
							while($rows= mysqli_fetch_array($resultclist))
						{
		                  										
					    ?>
						<a  href="menu.php?catlistid=<?php echo $rows["category_id"]; ?>&catproid=<?php echo $rows["category_id"]; ?>&barcodelist=<?php echo $_GET['barcodelist']; ?>">
							<button class="btn btn-sm" style="background-color: #05131c; color:white; display:inline; margin:3px;"><?php  echo $rows["category_name"]; ?></button></a>
						<?php  
						}
						}	
						?>
			
			</p>
			</div>
			<br />



			
			
			
		<div class="row">

			
			
			
            <div class="col-xl-8 col-md-11">
			<div id="display_item">


			</div>
			<br><br>
			</div>
			<br><br><br>
		</div>
		</div>
		<br><br><br><br>
	</body>
</html>

<script> 



 
$(document).ready(function(){

	load_product();

	load_cart_data();
    
	function load_product()
	{
		
		var categoryid='<?php echo $_GET['catlistid'];  ?>';
		var barcode=<?php echo $_GET['barcodelist'];  ?>;
		$.ajax({
			url:"fetch_item.php",
			data: {categoryid:categoryid , barcode:barcode},
			method:"POST",
			success:function(data)
			{
				$('#display_item').html(data);
			}
		});
	}






	$('#cart-popover').popover({
		html : true,
        container: 'body',
        content:function(){
        	return $('#popover_content_wrapper').html();
			
        }
	});

	$(document).on('click', '.add_to_cart', function(){
		var product_id = $(this).attr("id");
		var product_name = $('#name'+product_id+'').val();
		var product_price = $('#price'+product_id+'').val();
		var product_quantity = $('#quantity'+product_id).val();
		var product_discount = $('#discount'+product_id).val();
		var product_batchno = $('#batchno'+product_id).val();
		var action = "add";
		if(product_quantity > 0)
		{
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, product_name:product_name, product_price:product_price, product_quantity:product_quantity, product_discount:product_discount, product_batchno:product_batchno, action:action},
				success:function(data)
				{
					load_cart_data();
					
				}
			});
		}
		else
		{
			alert("lease Enter Number of Quantity");
		}
	});

$(document).on('click', '.padd', function(){
		var product_id = $(this).attr("id");
		var action = 'padd';
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					
				}
			})
		
	});
	
	
	$(document).on('click', '.porminus', function(){
		var product_id = $(this).attr("id");
		var action = 'porminus';
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					
				}
			})
		
	});

	$(document).on('click', '.delete', function(){
		var product_id = $(this).attr("id");
		var action = 'remove';
		if(confirm("Are you sure you want to remove this product?"))
		{
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{product_id:product_id, action:action},
				success:function()
				{
					load_cart_data();
					$('#cart-popover').popover('hide');
					
				}
			})
		}
		else
		{
			return false;
		}
	});

	$(document).on('click', '#clear_cart', function(){
		var action = 'empty';
		$.ajax({
			url:"action.php",
			method:"POST",
			data:{action:action},
			success:function()
			{
				load_cart_data();
				$('#cart-popover').popover('hide');
				alert("Your invoice has been clear");
			}
		});
	});
    
});

</script>
