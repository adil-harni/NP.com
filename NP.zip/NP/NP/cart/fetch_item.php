<?php

//fetch_item.php

include('../config.php');
       $categoryid=$_POST["categoryid"];
	   $categoryidgo=htmlspecialchars($categoryid, ENT_QUOTES);
	  
	  if($categoryidgo !='all'){
    
		 $query = "SELECT * FROM tbl_product  WHERE tbl_product.available='Active' and  category_id='".$categoryidgo."' order by product_name";  
	  }else{
		 
$query = "SELECT * FROM tbl_product order by product_name ";  
			 
		  
	  }
	$countnum=1;   
$statement = $connect->prepare($query);
if($statement->execute())
{    
$output = '';
 $output .= '<div class="row">';
	$result = $statement->fetchAll();
	
	foreach($result as $row)
	{
		
	$output .= '
		<input type="hidden" name="hidden_batchno" id="batchno'.$row["product_id"].'" value="0" />
        <input type="hidden" name="hidden_name" id="name'.$row["product_id"].'" value="'.$row["product_name"].'" />
        <input type="hidden" name="hidden_price" id="price'.$row["product_id"].'" value="'.$row["product_price"].'" />
		<input  type="hidden" name="discount" id="discount'.$row["product_id"].'" value="0" />
		
		<div class="col-xl-4 col-md-4" style="border:1px solid #9f9797; margin-top:12px; border-radius:5px; padding:-10px;" >
		<div class="card shadow text-center">
		<div class="card-body" align="center" style="padding:2px;">
       <img src=../'.$row["product_img"].' class="img-responsive" style="height: 80px; width: 80px;">
       
	   <p style="font-size:13px;">'.$row["product_name"].'</p>
       <p>'.(number_format($row["product_price"])).' IQD</p>
	   <input type="hidden" name="quantity" id="quantity'.$row["product_id"].'" value="1" class="form-control" min="1"   placeholder="Quantity" />
        <div class="options mt-2">      
	  <input style="margin-bottom:5px; background-color: #05131c; color:white;" type="button" name="add_to_cart" id="'.$row["product_id"].'"  class="btn form-control add_to_cart" value="&#10009;" />
	  
	  </div>
	</div>
	</div>
	</div>
   
		';
	}
	$output .= '</div>';
	echo $output;
}
 
?>