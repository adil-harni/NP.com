<?php
//index.php
ob_start();
session_start();
if(isset($_SESSION['posseetango_id']))
{
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Inventory</title>
		<link href="../assets/larsalogo.png" rel="icon" type="image/png">
		<script src="js/jquery.min.js"></script>
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<script src="js/bootstrap.min.js"></script>
		<style>
		.popover
		{
		    width: 100%;
		    max-width: 800px;
		}
		</style>
	</head>
	<body>
		<div class="container">
			<br>
			<h4 align="center">
			<a href="../catagorytlist.php"> 
			<button class="btn btn-primary" >&#8592; Go Back</button>
			</a></h4>
			<br />
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<div class="navbar-header">
						
					</div>
					
					<div id="navbar-cart" class="navbar-collapse collapse">
						<ul class="nav navbar-nav">
							
						</ul>
					</div>
					
				</div>
			</nav>
		   
		   <div align="center">
		   <h3 class="text-success">Order Placed Successfully</h3>
		   <img src="img/orderplaced.jpg" class="img-responsive" >
		   </div>
           <?php unset($_SESSION["shopping_cart"]);  ?>

			
		</div>
	</body>
</html>
<?php 
}
else{	
echo "<script>window.location.assign('index.php')</script>";
ob_end_flush();
 }  
?>



