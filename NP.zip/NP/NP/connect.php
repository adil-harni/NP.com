<?php 
//connect.php;
$connect = mysqli_connect("localhost", "root", "", "pin_management");
?>