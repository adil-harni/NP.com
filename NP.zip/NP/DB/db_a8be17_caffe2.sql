-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2023 at 05:15 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_a8be17_caffe2`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_table`
--

CREATE TABLE `account_table` (
  `account_id` bigint(20) NOT NULL,
  `account_username` varchar(255) NOT NULL,
  `account_password` varchar(255) NOT NULL,
  `account_full_name` varchar(255) NOT NULL,
  `account_static` varchar(255) NOT NULL DEFAULT 'Deactive',
  `account_type` varchar(255) NOT NULL,
  `user_position` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `account_table`
--

INSERT INTO `account_table` (`account_id`, `account_username`, `account_password`, `account_full_name`, `account_static`, `account_type`, `user_position`) VALUES
(2, 'admin', '202cb962ac59075b964b07152d234b70', 'Barzan', 'active', 'admin', 'ceo'),
(13, 'ipad', '202cb962ac59075b964b07152d234b70', 'iPad', 'Active', 'User', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `acc_join_cate`
--

CREATE TABLE `acc_join_cate` (
  `acc_join_cate_id` int(11) NOT NULL,
  `acc_id` int(11) NOT NULL,
  `cate_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `acc_join_cate`
--

INSERT INTO `acc_join_cate` (`acc_join_cate_id`, `acc_id`, `cate_id`) VALUES
(64, 2, 1),
(66, 2, 34),
(67, 2, 19),
(68, 2, 18),
(69, 2, 2),
(75, 13, 1),
(76, 13, 2),
(77, 13, 34),
(78, 13, 19),
(79, 13, 18);

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `borrow_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` bigint(20) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `status`) VALUES
(1, 'Nargila', 'Active'),
(2, 'Sardamani', 'Active'),
(18, 'Xarn', 'Active'),
(19, 'Vaxarnet Garm', 'Active'),
(34, 'Table Price', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `comment_subject` varchar(250) NOT NULL,
  `comment_text` text NOT NULL,
  `comment_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_subject`, `comment_text`, `comment_status`) VALUES
(1, '3', 'reqqw', 1),
(2, '2', 'test', 1),
(3, '3', '123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `employees_table`
--

CREATE TABLE `employees_table` (
  `employee_id` bigint(20) NOT NULL,
  `emp_name` varchar(255) NOT NULL,
  `emp_salary` varchar(255) NOT NULL DEFAULT '0',
  `emp_phone` varchar(200) NOT NULL,
  `emp_title` varchar(255) NOT NULL,
  `emp_status` varchar(200) NOT NULL DEFAULT 'Deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `employees_table`
--

INSERT INTO `employees_table` (`employee_id`, `emp_name`, `emp_salary`, `emp_phone`, `emp_title`, `emp_status`) VALUES
(1, 'test', '0002', '083956472098', 'test', 'Active'),
(2, 'iPad', '0', '0987654', 'Captain', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `expanse_table`
--

CREATE TABLE `expanse_table` (
  `expanse_id` bigint(20) NOT NULL,
  `expanse_desc` varchar(500) NOT NULL,
  `expanse_date` date NOT NULL,
  `expanse_amount` varchar(255) NOT NULL DEFAULT '0',
  `currency_type` varchar(200) NOT NULL,
  `expanse_vender` varchar(255) NOT NULL,
  `expanse_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `expanse_table`
--

INSERT INTO `expanse_table` (`expanse_id`, `expanse_desc`, `expanse_date`, `expanse_amount`, `currency_type`, `expanse_vender`, `expanse_type`) VALUES
(1, 'test expanse', '2023-02-22', '25000', 'IQD', 'test', 'Expanse'),
(2, 'test', '2023-05-01', '0002', 'IQD', 'N/A', 'Salary'),
(3, 'iPad', '2023-05-01', '0', 'IQD', 'N/A', 'Salary');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `food_name` varchar(255) NOT NULL,
  `food_category` varchar(255) NOT NULL,
  `food_price` varchar(255) NOT NULL,
  `food_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `food_name`, `food_category`, `food_price`, `food_description`) VALUES
(1, 'spicyburger', 'lunch', '50.00', 'Vestibulum tortor quam feugiat vitae ultricies eget tempor sit amet ante Donec eu libero sit amet quam egestas semper Aenean ultricies mi vitae est Mauris placerat eleifend leo Quisque sit amet est et sapien ullamcorper pharetra Vestibulum erat wisi condimentum sed commodo vitae'),
(2, 'snailchoc', 'breakfast', '50.00', 'Vestibulum tortor quam feugiat vitae ultricies eget tempor sit amet ante Donec eu libero sit amet quam egestas semper Aenean ultricies mi vitae est Mauris placerat eleifend leo Quisque sit amet est et sapien ullamcorper pharetra Vestibulum erat wisi condimentum sed commodo vitae'),
(3, 'salad', 'lunch', '50.00', 'Vestibulum tortor quam feugiat vitae ultricies eget tempor sit amet ante Donec eu libero sit amet quam egestas semper Aenean ultricies mi vitae est Mauris placerat eleifend leo Quisque sit amet est et sapien ullamcorper pharetra Vestibulum erat wisi condimentum sed commodo vitae'),
(4, 'pizza', 'lunch', '350.00', 'Vestibulum tortor quam feugiat vitae ultricies eget tempor sit amet ante Donec eu libero sit amet quam egestas semper Aenean ultricies mi vitae est Mauris placerat eleifend leo Quisque sit amet est et sapien ullamcorper pharetra Vestibulum erat wisi condimentum sed commodo vitae'),
(5, 'shawarma', 'breakfast', '350.00', 'Vestibulum tortor quam feugiat vitae ultricies eget tempor sit amet ante Donec eu libero sit amet quam egestas semper Aenean ultricies mi vitae est Mauris placerat eleifend leo Quisque sit amet est et sapien ullamcorper pharetra Vestibulum erat wisi condimentum sed commodo vitae'),
(6, 'Rice', 'lunch', '50.00', 'This is a tasty meal i bet you dont want miss enjoying the yummy taste'),
(7, 'Jellyfish', 'dinner', '400', 'Try this delicay and i promise you will keep coming back for more'),
(8, 'Ice Cream', 'special', '4000', 'desc'),
(9, 'Pounded Yam', 'dinner', '800', 'This is one of our best meal and it is prepared deliciously for you'),
(10, 'Eba and Vegetable', 'dinner', '600', 'This is a very nice combination'),
(11, 'Somovita and Egusi soup', 'breakfast', '800', 'Semovita is one of the delicacies you definitely want to try for breakfast');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `order_id` varchar(100) NOT NULL,
  `food` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `order_id`, `food`, `qty`) VALUES
(1, '13', 'pizza', '2');

-- --------------------------------------------------------

--
-- Table structure for table `order_list_table`
--

CREATE TABLE `order_list_table` (
  `order_list_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `order_category_id` int(11) NOT NULL,
  `order_product_id` bigint(20) NOT NULL,
  `order_product_name` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `order_product_qty` varchar(200) NOT NULL,
  `order_product_price` varchar(100) NOT NULL,
  `order_item_status` varchar(255) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_list_table`
--

INSERT INTO `order_list_table` (`order_list_id`, `order_id`, `order_category_id`, `order_product_id`, `order_product_name`, `order_product_qty`, `order_product_price`, `order_item_status`) VALUES
(1, 1, 1, 4, 'Baghdadi', '1', '5000', 'APPROVED'),
(2, 1, 2, 8, 'Av', '1', '500', 'Pending'),
(3, 2, 2, 17, 'Fanta', '1', '1000', 'APPROVED'),
(4, 2, 2, 19, 'Shirmoz', '2', '2500', 'APPROVED'),
(5, 3, 2, 8, 'Av', '4', '500', 'APPROVED');

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  `order_date` date NOT NULL,
  `system_user` varchar(200) NOT NULL DEFAULT 'N/A',
  `entry_datetime` datetime NOT NULL,
  `payment_type` varchar(200) NOT NULL DEFAULT 'Cash',
  `order_status` varchar(50) NOT NULL DEFAULT 'Pending',
  `kitchin_status` varchar(200) NOT NULL DEFAULT 'Pending',
  `payment_ammount` varchar(255) NOT NULL DEFAULT '0',
  `paid_amount` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `order_table`
--

INSERT INTO `order_table` (`order_id`, `client_id`, `order_date`, `system_user`, `entry_datetime`, `payment_type`, `order_status`, `kitchin_status`, `payment_ammount`, `paid_amount`) VALUES
(1, 1, '2023-05-03', 'BARO', '2023-05-03 15:15:00', 'N/A', 'APPROVED', 'Pending', '5500', '5500'),
(3, 1, '2023-05-08', 'Barzan', '2023-05-08 16:04:00', 'N/A', 'APPROVED', 'Pending', '2000', '1500');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `pr_id` bigint(20) NOT NULL,
  `per_role` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'no',
  `acc_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`pr_id`, `per_role`, `status`, `acc_id`) VALUES
(12, 'catagory', 'yes', 2),
(13, 'addcatagory', 'yes', 2),
(14, 'updatecatagory', 'yes', 2),
(15, 'product', 'yes', 2),
(16, 'addproduct', 'yes', 2),
(17, 'updateproduct', 'yes', 2),
(18, 'downloadproduct', 'yes', 2),
(19, 'accountlist', 'yes', 2),
(20, 'employeelist', 'yes', 2),
(21, 'addemployee', 'yes', 2),
(22, 'updateemployee', 'yes', 2),
(23, 'employeerole', 'yes', 2),
(25, 'Permission', 'yes', 2),
(26, 'SystemConstent', 'yes', 2),
(27, 'Orderlist', 'yes', 2),
(30, 'MonthlyReport', 'yes', 2),
(31, 'itemreport', 'yes', 2),
(32, 'addpayroll', 'yes', 2),
(33, 'Dashboard', 'yes', 2),
(34, 'Dashboardinfo', 'yes', 2),
(35, 'OrderlistNew', 'yes', 2),
(36, 'OrderlistNew', 'yes', 2),
(37, 'Borrow', 'yes', 2),
(150, 'Dashboard', 'yes', 2),
(151, 'Orderlist', 'yes', 2),
(152, 'OrderlistNew', 'yes', 2),
(153, 'cheeforder', 'yes', 2),
(154, 'casherorder', 'yes', 2),
(155, 'Tablelist', 'yes', 2),
(156, 'addtable', 'yes', 2),
(157, 'updatetable', 'yes', 2),
(158, 'AllTables', 'yes', 2),
(159, 'Expensetable', 'yes', 2),
(160, 'addexpanse', 'yes', 2),
(161, 'updateexpanse', 'yes', 2),
(162, 'catagory', 'yes', 2),
(163, 'addcatagory', 'yes', 2),
(164, 'updatecatagory', 'yes', 2),
(165, 'product', 'yes', 2),
(166, 'addproduct', 'yes', 2),
(167, 'updateproduct', 'yes', 2),
(168, 'downloadproduct', 'yes', 2),
(169, 'accountlist', 'yes', 2),
(170, 'employeelist', 'yes', 2),
(171, 'addemployee', 'yes', 2),
(172, 'Dashboard', 'yes', 2),
(173, 'Orderlist', 'yes', 2),
(174, 'OrderlistNew', 'yes', 2),
(175, 'cheeforder', 'yes', 2),
(176, 'casherorder', 'yes', 2),
(177, 'Tablelist', 'yes', 2),
(178, 'addtable', 'yes', 2),
(179, 'updatetable', 'yes', 2),
(180, 'AllTables', 'yes', 2),
(181, 'Expensetable', 'yes', 2),
(182, 'addexpanse', 'yes', 2),
(183, 'updateexpanse', 'yes', 2),
(184, 'catagory', 'yes', 2),
(185, 'addcatagory', 'yes', 2),
(186, 'updatecatagory', 'yes', 2),
(187, 'product', 'yes', 2),
(188, 'addproduct', 'yes', 2),
(189, 'updateproduct', 'yes', 2),
(224, 'Dashboard', 'yes', 13),
(225, 'Dashboardinfo', 'yes', 13),
(232, 'Reservation', 'yes', 2),
(233, 'Reservation', 'yes', 2);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reserve_id` int(11) NOT NULL,
  `no_of_guest` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `date_res` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL,
  `suggestions` varchar(100) NOT NULL,
  `status` varchar(255) NOT NULL,
  `money` varchar(255) NOT NULL,
  `code` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reserve_id`, `no_of_guest`, `email`, `phone`, `date_res`, `time`, `suggestions`, `status`, `money`, `code`) VALUES
(1, '1', 'bskbsk@gmail.com', '07504404554', '2023-05-17', '17:48', '', 'Pending', 'Not Received', 'UNIQUE_407504404554'),
(2, '3', 'bsk@gmail.com', '6727363276', '2023-05-20', '17:56', '', 'Pending', 'Not Received', 'UNIQUE_106727363276'),
(3, '2', 'bskbsk@gmail.com', '07504404554', '2023-05-18', '17:58', '', 'Pending', 'Not Received', 'UNIQUE_407504404554'),
(4, '1', 'bskbsk@gmail.com', '07504404554', '2023-05-23', '17:58', '', 'Pending', 'Not Received', 'UNIQUE_407504404554'),
(5, '2', 'adil@yahoo.com', '9647502020291', '2023-05-19', '18:04', '', 'Pending', 'Not Received', 'UNIQUE_119647502020291'),
(6, '3', 'adil.00581605@gmail.com', '9647502020291', '2023-05-26', '21:05', '', 'Pending', 'Not Received', 'UNIQUE_119647502020291'),
(7, '2', 'bsk@gmail.com', '6727363276', '2023-05-19', '19:05', '', 'Pending', 'Not Received', 'UNIQUE_106727363276'),
(8, '2', 'adil@yahoo.com', '9647502020291', '2023-05-22', '18:11', '', 'Pending', 'Not Received', 'UNIQUE_119647502020291'),
(9, '3', 'adil.00581605@gmail.com', '9647502020291', '2023-05-08', '18:10', '', 'Pending', 'Not Received', 'UNIQUE_119647502020291'),
(10, '4', 'bskbsk@gmail.com', '6727363276', '2023-05-08', '18:12', '', 'Pending', 'Not Received', 'UNIQUE_106727363276'),
(11, '43', 'adil.00581605@gmail.com', '9647502020291', '2023-05-08', '18:12', '', 'Pending', 'Not Received', 'UNIQUE_119647502020291');

-- --------------------------------------------------------

--
-- Table structure for table `res_tables`
--

CREATE TABLE `res_tables` (
  `table_id` int(11) NOT NULL,
  `table_num` varchar(400) NOT NULL,
  `table_type` varchar(100) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'Deactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `res_tables`
--

INSERT INTO `res_tables` (`table_id`, `table_num`, `table_type`, `status`) VALUES
(1, '1', 'normal', 'Active'),
(2, '2', 'normal', 'Active'),
(3, '3', 'normal', 'Active'),
(4, '4', 'normal', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `system_content_table`
--

CREATE TABLE `system_content_table` (
  `systemcontid` int(11) NOT NULL,
  `company_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `company_description` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `company_address` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `company_email` varchar(200) NOT NULL,
  `company_phone` varchar(200) NOT NULL,
  `company_logo` varchar(500) NOT NULL,
  `invoice_footer` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `system_content_table`
--

INSERT INTO `system_content_table` (`systemcontid`, `company_name`, `company_description`, `company_address`, `company_email`, `company_phone`, `company_logo`, `invoice_footer`) VALUES
(20, 'Ramin,Barzan', 'Cafeteria Management System ', 'Soran, Mergasor', 'rra040@cs.soran.edu.iq - bsk099@cs.soran.edu.iq', '750 2020292 - 750 3765599 ', 'assets/com/14082021212931images.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `product_id` bigint(20) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_name` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `product_price` varchar(200) NOT NULL DEFAULT '0',
  `available` varchar(200) NOT NULL DEFAULT 'Deactive',
  `product_img` varchar(500) NOT NULL DEFAULT 'N/A'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`product_id`, `category_id`, `product_name`, `product_price`, `available`, `product_img`) VALUES
(1, 1, 'Banisht', '5000', 'Deactive ', 'productimage/03052023142316'),
(2, 1, 'Limon', '5000', 'Active', 'productimage/01052023192605download.jfif'),
(4, 1, 'Baghdadi', '5000', 'Active', 'productimage/01052023192605download.jfif'),
(8, 2, 'Av', '500', 'Active', ''),
(9, 2, 'Tiger', '1500', 'Active', ''),
(13, 2, 'Freez', '1500', 'Active', ''),
(15, 2, 'Cola', '1000', 'Active', ''),
(16, 2, 'Sprite', '1000', 'Active', ''),
(17, 2, 'Fanta', '1000', 'Active', ''),
(19, 2, 'Shirmoz', '2500', 'Active', ''),
(27, 19, 'cha', '500', 'Active', ''),
(28, 19, 'Shir', '1000', 'Active', ''),
(29, 19, 'Capachino', '1000', 'Active', ''),
(30, 19, 'Niscaffe', '1000', 'Active', ''),
(37, 19, 'kek', '500', 'Active', ''),
(35, 18, 'Tka', '2000', 'Active', ''),
(43, 18, 'Melak', '1500', 'Active', ''),
(36, 18, 'gass', '1000', 'Active', ''),
(38, 18, 'sing', '1500', 'Active', ''),
(42, 18, 'Kabab', '1500', 'Active', ''),
(50, 1, 'nargila sroshti', '10000', 'Deactive ', 'productimage/0305202314081801052023192605download.jfif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_table`
--
ALTER TABLE `account_table`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `acc_join_cate`
--
ALTER TABLE `acc_join_cate`
  ADD PRIMARY KEY (`acc_join_cate_id`);

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`borrow_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `employees_table`
--
ALTER TABLE `employees_table`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `expanse_table`
--
ALTER TABLE `expanse_table`
  ADD PRIMARY KEY (`expanse_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `order_list_table`
--
ALTER TABLE `order_list_table`
  ADD PRIMARY KEY (`order_list_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`pr_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reserve_id`);

--
-- Indexes for table `res_tables`
--
ALTER TABLE `res_tables`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `system_content_table`
--
ALTER TABLE `system_content_table`
  ADD PRIMARY KEY (`systemcontid`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_table`
--
ALTER TABLE `account_table`
  MODIFY `account_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `acc_join_cate`
--
ALTER TABLE `acc_join_cate`
  MODIFY `acc_join_cate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `borrow`
--
ALTER TABLE `borrow`
  MODIFY `borrow_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employees_table`
--
ALTER TABLE `employees_table`
  MODIFY `employee_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `expanse_table`
--
ALTER TABLE `expanse_table`
  MODIFY `expanse_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `order_list_table`
--
ALTER TABLE `order_list_table`
  MODIFY `order_list_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permission_role`
--
ALTER TABLE `permission_role`
  MODIFY `pr_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=234;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `reserve_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `res_tables`
--
ALTER TABLE `res_tables`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `system_content_table`
--
ALTER TABLE `system_content_table`
  MODIFY `systemcontid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `product_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
